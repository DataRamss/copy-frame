"use strict";
(() => {
  // src/shortcut.ts
  var DEFAULT_TOGGLE_SHORTCUT = "Alt+C";
  var TOGGLE_SHORTCUT_STORAGE_KEY = "toggleShortcut";
  var MODIFIER_ALIASES = /* @__PURE__ */ new Map([
    ["alt", "altKey"],
    ["ctrl", "ctrlKey"],
    ["control", "ctrlKey"],
    ["cmd", "metaKey"],
    ["command", "metaKey"],
    ["meta", "metaKey"],
    ["shift", "shiftKey"]
  ]);
  var DISPLAY_NAMES = {
    ctrlKey: "Ctrl",
    altKey: "Alt",
    shiftKey: "Shift",
    metaKey: "Cmd"
  };
  var MODIFIER_KEYS = /* @__PURE__ */ new Set(["alt", "control", "ctrl", "shift", "meta", "command", "cmd"]);
  function normalizeKeyToken(token) {
    if (!token) {
      return "";
    }
    if (token.length === 1) {
      return token.toUpperCase();
    }
    if (/^f\d{1,2}$/i.test(token)) {
      return token.toUpperCase();
    }
    if (token.toLowerCase() === "space") {
      return "Space";
    }
    if (token.toLowerCase() === "esc" || token.toLowerCase() === "escape") {
      return "Escape";
    }
    return token.slice(0, 1).toUpperCase() + token.slice(1).toLowerCase();
  }
  function parseShortcut(value) {
    const tokens = value.split("+").map((token) => token.trim()).filter(Boolean);
    if (!tokens.length) {
      return null;
    }
    const config = {
      altKey: false,
      ctrlKey: false,
      metaKey: false,
      shiftKey: false,
      key: ""
    };
    for (const token of tokens) {
      const modifier = MODIFIER_ALIASES.get(token.toLowerCase());
      if (modifier) {
        config[modifier] = true;
        continue;
      }
      if (config.key) {
        return null;
      }
      config.key = normalizeKeyToken(token);
    }
    if (!config.key || !config.altKey && !config.ctrlKey && !config.metaKey && !config.shiftKey) {
      return null;
    }
    const parts = [
      config.ctrlKey ? DISPLAY_NAMES.ctrlKey : null,
      config.altKey ? DISPLAY_NAMES.altKey : null,
      config.shiftKey ? DISPLAY_NAMES.shiftKey : null,
      config.metaKey ? DISPLAY_NAMES.metaKey : null,
      config.key
    ].filter(Boolean);
    return {
      ...config,
      label: parts.join("+")
    };
  }
  function matchesShortcut(event, shortcut) {
    return event.altKey === shortcut.altKey && event.ctrlKey === shortcut.ctrlKey && event.metaKey === shortcut.metaKey && event.shiftKey === shortcut.shiftKey && normalizeKeyToken(event.key) === shortcut.key;
  }
  function shortcutFromKeyboardEvent(event) {
    const key = event.key.trim();
    if (!key || MODIFIER_KEYS.has(key.toLowerCase())) {
      return null;
    }
    if (!event.altKey && !event.ctrlKey && !event.metaKey && !event.shiftKey) {
      return null;
    }
    return parseShortcut(
      [
        event.ctrlKey ? DISPLAY_NAMES.ctrlKey : null,
        event.altKey ? DISPLAY_NAMES.altKey : null,
        event.shiftKey ? DISPLAY_NAMES.shiftKey : null,
        event.metaKey ? DISPLAY_NAMES.metaKey : null,
        normalizeKeyToken(key)
      ].filter(Boolean).join("+")
    );
  }

  // src/content.ts
  var TOGGLE_INSPECT_MODE = "toggleInspectMode";
  var GET_PAGE_URL = "getPageUrl";
  var ROOT_ID = "copy-frame-root";
  var LOGO_URL = chrome.runtime.getURL("logo.png");
  var STARTUP_TOAST_MESSAGE = "Copy Frame \u5DF2\u5F00\u542F";
  var EXIT_TOAST_MESSAGE = "Copy Frame \u5DF2\u5173\u95ED";
  var MAX_TEXT_LENGTH = 80;
  var MAX_HINTS = 4;
  var TOAST_TOTAL_MS = 2400;
  var TOAST_ENTER_MS = 360;
  var TOAST_LEAVE_MS = 160;
  var TOAST_TEXT_DELAY_MS = 145;
  var TOAST_CHAR_STAGGER_MS = 16;
  var TOAST_CHAR_STAGGER_CAP_MS = 180;
  var TOAST_CHAR_ENTER_MS = 180;
  var TOAST_SETTINGS_REVEAL_BUFFER_MS = 40;
  var SHORTCUT_TOKEN_LEAVE_MS = 180;
  var GENERIC_CLASS_NAMES = /* @__PURE__ */ new Set([
    "active",
    "body",
    "card",
    "col",
    "container",
    "content",
    "dialog",
    "icon",
    "input",
    "item",
    "label",
    "main",
    "page",
    "panel",
    "row",
    "section",
    "selected",
    "title",
    "value",
    "wrapper"
  ]);
  var CopyFrameInspector = class {
    state = "idle";
    host;
    shadowRootRef;
    borderEl;
    hoverBorderEl;
    labelEl;
    copyButtonEl;
    toastEl;
    toastTextEl;
    toastSettingsButtonEl;
    settingsPanelEl;
    settingsInputEl;
    settingsShortcutFieldEl;
    settingsShortcutTokenEl;
    settingsStatusEl;
    settingsCloseButtonEl;
    settingsSaveButtonEl;
    settingsFormEl;
    currentElement = null;
    hoverElement = null;
    currentDescriptor = null;
    toastTimer = null;
    toastCleanupTimer = null;
    toastSettingsRevealTimer = null;
    shortcutTokenLeaveTimer = null;
    refreshFrame = null;
    pointerClientX = null;
    pointerClientY = null;
    drillStack = [];
    selectionHistory = [];
    historyIndex = -1;
    toggleShortcut = parseShortcut(DEFAULT_TOGGLE_SHORTCUT);
    settingsVisible = false;
    toastVisible = false;
    shortcutInputFocused = false;
    constructor() {
      this.host = document.createElement("div");
      this.host.id = ROOT_ID;
      this.host.style.display = "none";
      document.addEventListener("keydown", this.handleGlobalKeydown, true);
      chrome.storage.onChanged.addListener(this.handleStorageChange);
      this.shadowRootRef = this.host.attachShadow({ mode: "open" });
      this.shadowRootRef.innerHTML = `
      <style>
        :host {
          all: initial;
        }

        .cf-layer {
          --cf-accent: #EE46BC;
          --cf-fill: rgba(238, 70, 188, 0.1);
          position: fixed;
          inset: 0;
          z-index: 2147483647;
          pointer-events: none;
          font-family: "Satoshi Variable", "Satoshi", "Avenir Next", "Segoe UI", sans-serif;
        }

        .cf-border {
          position: fixed;
          display: none;
          overflow: visible;
          border: 1px solid var(--cf-accent);
          background: var(--cf-fill);
          border-radius: 0;
          box-sizing: border-box;
        }

        .cf-hover-border {
          position: fixed;
          display: none;
          overflow: visible;
          border: 1px solid rgba(238, 70, 188, 0.85);
          background: rgba(238, 70, 188, 0.04);
          border-radius: 0;
          box-sizing: border-box;
        }

        .cf-badge {
          position: absolute;
          top: -21px;
          left: -1px;
          width: fit-content;
          max-width: min(420px, calc(100vw - 96px));
          display: none;
          align-items: center;
          height: 20px;
          padding: 0 8px;
          border-radius: 0;
          background: var(--cf-accent);
          color: #ffffff;
          font-size: 10px;
          font-weight: 500;
          line-height: 1;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
          box-sizing: border-box;
        }

        .cf-copy {
          position: absolute;
          top: -21px;
          right: -1px;
          display: none;
          align-items: center;
          justify-content: center;
          height: 20px;
          padding: 0 8px;
          border: 0;
          border-radius: 0;
          background: var(--cf-accent);
          color: #ffffff;
          cursor: pointer;
          font-size: 10px;
          font-weight: 500;
          line-height: 1;
          pointer-events: auto;
          font-family: inherit;
          white-space: nowrap;
          box-sizing: border-box;
        }

        .cf-copy:hover {
          background: var(--cf-accent);
        }

        .cf-border.cf-chip-bottom .cf-badge,
        .cf-border.cf-chip-bottom .cf-copy {
          top: calc(100% + 1px);
        }

        .cf-toast {
          position: fixed;
          z-index: 1;
          right: 20px;
          bottom: 20px;
          max-width: min(420px, calc(100vw - 32px));
          display: none;
          overflow: hidden;
          pointer-events: none;
          clip-path: inset(0 0 0 0);
          will-change: clip-path;
          transition: clip-path ${TOAST_LEAVE_MS}ms cubic-bezier(0.16, 1, 0.3, 1);
          --cf-toast-enter-ms: ${TOAST_ENTER_MS}ms;
          --cf-toast-text-delay: ${TOAST_TEXT_DELAY_MS}ms;
        }

        .cf-toast.is-leaving {
          clip-path: inset(0 0 0 100%);
        }

        .cf-toast__surface {
          position: absolute;
          inset: 0;
          background: #000000;
          transform-origin: left center;
          transform: scaleX(0.04);
          opacity: 0;
          will-change: transform, opacity;
          transition:
            transform var(--cf-toast-enter-ms) cubic-bezier(0.16, 1, 0.3, 1),
            opacity 140ms ease-out;
        }

        .cf-toast.is-entering .cf-toast__surface,
        .cf-toast.is-visible .cf-toast__surface,
        .cf-toast.is-leaving .cf-toast__surface {
          transform: scaleX(1);
          opacity: 1;
        }

        .cf-toast__body {
          position: relative;
          display: flex;
          align-items: center;
          min-width: 0;
        }

        .cf-toast__content {
          position: relative;
          flex: 1 1 auto;
          min-width: 0;
          padding: 10px 14px;
          color: #ffffff;
          font-size: 12px;
          font-weight: 500;
          line-height: 1.45;
          white-space: pre-wrap;
          word-break: break-word;
        }

        .cf-toast--with-settings .cf-toast__content {
          padding-right: 8px;
        }

        .cf-toast__settings {
          position: relative;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          flex: 0 0 28px;
          width: 28px;
          height: 18px;
          margin: 0 8px 0 0;
          border: 0;
          border-radius: 4px;
          background: rgba(255, 255, 255, 0.08);
          color: #ffffff;
          cursor: pointer;
          opacity: 0;
          filter: blur(6px);
          pointer-events: none;
          transition:
            background 120ms ease-out,
            opacity 140ms ease-out,
            transform 180ms cubic-bezier(0.22, 1, 0.36, 1),
            filter 180ms ease-out;
          transform: translateX(6px);
        }

        .cf-toast__settings[hidden] {
          display: none;
        }

        .cf-toast__settings.is-visible {
          opacity: 1;
          filter: blur(0);
          pointer-events: auto;
          transform: translateX(0);
        }

        .cf-toast__settings:hover {
          background: rgba(255, 255, 255, 0.18);
        }

        .cf-toast__settings:focus-visible {
          outline: 1px solid #ffffff;
          outline-offset: 2px;
        }

        .cf-toast__settings.is-visible:active {
          transform: translateY(1px);
        }

        .cf-toast__settings svg {
          display: block;
          width: 14px;
          height: 14px;
        }

        .cf-toast-char {
          display: inline-block;
          opacity: 0;
          transform: translateX(6px);
          filter: blur(6px);
          will-change: transform, opacity, filter;
          transition:
            opacity 110ms ease-out,
            transform ${TOAST_CHAR_ENTER_MS}ms cubic-bezier(0.22, 1, 0.36, 1),
            filter ${TOAST_CHAR_ENTER_MS}ms ease-out;
          transition-delay: calc(var(--cf-toast-text-delay) + var(--cf-char-delay, 0ms));
        }

        .cf-toast.is-entering .cf-toast-char,
        .cf-toast.is-visible .cf-toast-char,
        .cf-toast.is-leaving .cf-toast-char {
          opacity: 1;
          transform: translateX(0);
          filter: blur(0);
        }

        .cf-settings {
          position: fixed;
          top: 20px;
          right: 20px;
          width: min(320px, calc(100vw - 32px));
          max-height: calc(100vh - 40px);
          display: none;
          flex-direction: column;
          gap: 12px;
          padding: 16px;
          border: 1px solid rgba(17, 24, 39, 0.08);
          background: #fafafa;
          color: #111827;
          pointer-events: auto;
          box-sizing: border-box;
          overflow-y: auto;
          overscroll-behavior: contain;
        }

        .cf-settings__header {
          display: flex;
          align-items: flex-start;
          justify-content: space-between;
          gap: 12px;
        }

        .cf-settings__brand {
          display: flex;
          align-items: center;
          gap: 12px;
        }

        .cf-settings__logo {
          width: 32px;
          height: 32px;
          flex: 0 0 32px;
          object-fit: contain;
        }

        .cf-settings__title {
          display: flex;
          align-items: center;
          gap: 0;
          font-size: 14px;
          font-weight: 600;
        }

        .cf-settings__chip {
          padding: 2px 6px;
          border: 1px solid #d1d5db;
          background: #ffffff;
          font-size: 11px;
          line-height: 1.2;
          white-space: nowrap;
        }

        .cf-settings__close {
          position: relative;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          width: 20px;
          height: 20px;
          border: 0;
          background: transparent;
          color: #6b7280;
          line-height: 1;
          cursor: pointer;
          padding: 0;
          margin: 0;
          pointer-events: auto;
        }

        .cf-settings__close::before,
        .cf-settings__close::after {
          content: "";
          position: absolute;
          width: 12px;
          height: 1px;
          background: currentColor;
        }

        .cf-settings__close::before {
          transform: rotate(45deg);
        }

        .cf-settings__close::after {
          transform: rotate(-45deg);
        }

        .cf-settings__text,
        .cf-settings__status {
          font-size: 12px;
          line-height: 1.5;
          color: #6b7280;
        }

        .cf-settings__field {
          display: flex;
          flex-direction: column;
          gap: 6px;
        }

        .cf-settings__label,
        .cf-settings__section {
          font-size: 12px;
          font-weight: 600;
          color: #111827;
        }

        .cf-settings__reference {
          display: grid;
          gap: 10px;
        }

        .cf-settings__group {
          display: grid;
          gap: 5px;
        }

        .cf-settings__row {
          display: flex;
          gap: 0;
        }

        .cf-settings__shortcut-field {
          position: relative;
          flex: 1;
          min-width: 0;
          display: flex;
          align-items: center;
          border: 1px solid #d1d5db;
          background: #fafafa;
          box-sizing: border-box;
          overflow: hidden;
          transition:
            border-color 120ms ease-out,
            background 120ms ease-out,
            box-shadow 120ms ease-out;
        }

        .cf-settings__shortcut-field.is-focused {
          border-color: #111827;
          background: #ffffff;
          box-shadow: inset 3px 0 0 #111827;
        }

        .cf-settings__shortcut-token {
          position: absolute;
          left: 10px;
          top: 50%;
          max-width: calc(100% - 20px);
          padding: 2px 8px;
          border-radius: 4px;
          background: #f3f4f6;
          color: #111827;
          font-size: 12px;
          line-height: 1.35;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
          transform: translate(0, -50%);
          opacity: 1;
          pointer-events: none;
          isolation: isolate;
        }

        .cf-settings__shortcut-token::before {
          content: "";
          position: absolute;
          inset: 0;
          z-index: -1;
          border-radius: inherit;
          background: #e5e7eb;
          opacity: 0;
          transform: translateX(-100%);
        }

        .cf-settings__shortcut-field.is-focused .cf-settings__shortcut-token::before {
          opacity: 1;
          transform: translateX(0);
          animation: cf-shortcut-token-enter 180ms cubic-bezier(0.22, 1, 0.36, 1);
        }

        .cf-settings__shortcut-field.is-leaving .cf-settings__shortcut-token::before {
          opacity: 0;
          transform: translateX(100%);
          animation: cf-shortcut-token-leave 180ms cubic-bezier(0.22, 1, 0.36, 1);
        }

        @keyframes cf-shortcut-token-enter {
          from {
            opacity: 0;
            transform: translateX(-100%);
          }

          to {
            opacity: 1;
            transform: translateX(0);
          }
        }

        @keyframes cf-shortcut-token-leave {
          from {
            opacity: 1;
            transform: translateX(0);
          }

          to {
            opacity: 0;
            transform: translateX(100%);
          }
        }

        .cf-settings__input {
          flex: 1;
          min-width: 0;
          padding: 9px 10px;
          border: 0;
          background: transparent;
          color: transparent;
          caret-color: transparent;
          font: inherit;
          font-size: 13px;
          box-sizing: border-box;
        }

        .cf-settings__input::selection {
          background: transparent;
        }

        .cf-settings__input:focus {
          outline: none;
          box-shadow: none;
        }

        .cf-settings__save {
          border: 0;
          background: #111827;
          color: #ffffff;
          padding: 9px 12px;
          font: inherit;
          font-size: 12px;
          white-space: nowrap;
          cursor: pointer;
          pointer-events: auto;
        }

        .cf-settings__list {
          display: grid;
          gap: 3px;
        }

        .cf-settings__item {
          display: grid;
          grid-template-columns: minmax(72px, 1fr) minmax(0, auto);
          align-items: center;
          gap: 8px;
          padding: 7px 8px;
          background: #ffffff;
          font-size: 12px;
          line-height: 1.4;
        }

        .cf-settings__action {
          min-width: 0;
          color: #111827;
        }

        .cf-settings__kbd {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          max-width: 172px;
          padding: 2px 8px;
          border-radius: 4px;
          background: #f9f9f9;
          color: #000000;
          line-height: 1.4;
          white-space: nowrap;
          text-align: center;
        }

        .cf-settings__kbd--soft {
          color: #4b5563;
          white-space: normal;
        }

        @media (prefers-reduced-motion: reduce) {
          .cf-toast,
          .cf-toast__surface,
          .cf-toast-char,
          .cf-toast__settings,
          .cf-settings__shortcut-field,
          .cf-settings__shortcut-token {
            transition: none !important;
            animation: none !important;
          }

          .cf-toast__surface,
          .cf-toast-char,
          .cf-settings__shortcut-token {
            transform: none !important;
            filter: none !important;
          }
        }
      </style>
      <div class="cf-layer">
        <div class="cf-hover-border"></div>
        <div class="cf-border">
          <div class="cf-badge"></div>
          <button class="cf-copy" type="button">Copy</button>
        </div>
        <div class="cf-toast" role="status" aria-live="polite" aria-atomic="true">
          <div class="cf-toast__surface"></div>
          <div class="cf-toast__body">
            <div class="cf-toast__content" aria-hidden="true"></div>
            <button class="cf-toast__settings" type="button" aria-label="\u6253\u5F00\u5FEB\u6377\u952E\u8BBE\u7F6E" title="\u6253\u5F00\u5FEB\u6377\u952E\u8BBE\u7F6E" hidden>
              <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.09a2 2 0 0 1 1 1.73v.52a2 2 0 0 1-1 1.73l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.38a2 2 0 0 0-.73-2.73l-.15-.09a2 2 0 0 1-1-1.73v-.52a2 2 0 0 1 1-1.73l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"></path>
                <circle cx="12" cy="12" r="3"></circle>
              </svg>
            </button>
          </div>
        </div>
        <div class="cf-settings" aria-hidden="true">
          <div class="cf-settings__header">
            <div class="cf-settings__brand">
              <img class="cf-settings__logo" src="${LOGO_URL}" alt="Copy Frame logo" />
              <div>
                <div class="cf-settings__title">
                  <span>Copy Frame</span>
                </div>
                <div class="cf-settings__text">Point. Copy. For AI.</div>
              </div>
            </div>
            <button class="cf-settings__close" type="button" aria-label="\u5173\u95ED"></button>
          </div>
          <form class="cf-settings__field">
            <div class="cf-settings__label">\u542F\u52A8\u5FEB\u6377\u952E</div>
            <div class="cf-settings__row">
              <div class="cf-settings__shortcut-field">
                <input class="cf-settings__input" id="cf-toggle-shortcut" type="text" autocomplete="off" placeholder="${DEFAULT_TOGGLE_SHORTCUT}" readonly />
                <span class="cf-settings__shortcut-token" aria-hidden="true">${DEFAULT_TOGGLE_SHORTCUT}</span>
              </div>
              <button class="cf-settings__save" type="submit">\u4FDD\u5B58</button>
            </div>
          </form>
          <div class="cf-settings__status" aria-live="polite"></div>
          <div class="cf-settings__field">
            <div class="cf-settings__section">\u5FEB\u6377\u952E\u4E0E\u64CD\u4F5C</div>
            <div class="cf-settings__reference">
              <div class="cf-settings__list">
                <div class="cf-settings__item"><span class="cf-settings__action">\u590D\u5236</span><span class="cf-settings__kbd">Ctrl/Cmd+C</span></div>
                <div class="cf-settings__item"><span class="cf-settings__action">\u64A4\u9500</span><span class="cf-settings__kbd">Ctrl/Cmd+Z</span></div>
                <div class="cf-settings__item"><span class="cf-settings__action">\u540C\u7EA7\u5207\u6362</span><span class="cf-settings__kbd">Tab / Shift+Tab</span></div>
                <div class="cf-settings__item"><span class="cf-settings__action">\u7236\u5B50\u7EA7\u5207\u6362</span><span class="cf-settings__kbd">Enter / Shift+Enter</span></div>
                <div class="cf-settings__item"><span class="cf-settings__action">\u9000\u51FA\u9501\u5B9A</span><span class="cf-settings__kbd">Esc</span></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    `;
      const borderEl = this.shadowRootRef.querySelector(".cf-border");
      const hoverBorderEl = this.shadowRootRef.querySelector(".cf-hover-border");
      const labelEl = this.shadowRootRef.querySelector(".cf-badge");
      const copyButtonEl = this.shadowRootRef.querySelector(".cf-copy");
      const toastEl = this.shadowRootRef.querySelector(".cf-toast");
      const toastTextEl = this.shadowRootRef.querySelector(".cf-toast__content");
      const toastSettingsButtonEl = this.shadowRootRef.querySelector(".cf-toast__settings");
      const settingsPanelEl = this.shadowRootRef.querySelector(".cf-settings");
      const settingsInputEl = this.shadowRootRef.querySelector(".cf-settings__input");
      const settingsShortcutFieldEl = this.shadowRootRef.querySelector(".cf-settings__shortcut-field");
      const settingsShortcutTokenEl = this.shadowRootRef.querySelector(".cf-settings__shortcut-token");
      const settingsStatusEl = this.shadowRootRef.querySelector(".cf-settings__status");
      const settingsCloseButtonEl = this.shadowRootRef.querySelector(".cf-settings__close");
      const settingsSaveButtonEl = this.shadowRootRef.querySelector(".cf-settings__save");
      const settingsFormEl = this.shadowRootRef.querySelector("form.cf-settings__field");
      if (!borderEl || !hoverBorderEl || !labelEl || !copyButtonEl || !toastEl || !toastTextEl || !toastSettingsButtonEl || !settingsPanelEl || !settingsInputEl || !settingsShortcutFieldEl || !settingsShortcutTokenEl || !settingsStatusEl || !settingsCloseButtonEl || !settingsSaveButtonEl || !settingsFormEl) {
        throw new Error("Copy Frame UI failed to initialize.");
      }
      this.borderEl = borderEl;
      this.hoverBorderEl = hoverBorderEl;
      this.labelEl = labelEl;
      this.copyButtonEl = copyButtonEl;
      this.toastEl = toastEl;
      this.toastTextEl = toastTextEl;
      this.toastSettingsButtonEl = toastSettingsButtonEl;
      this.settingsPanelEl = settingsPanelEl;
      this.settingsInputEl = settingsInputEl;
      this.settingsShortcutFieldEl = settingsShortcutFieldEl;
      this.settingsShortcutTokenEl = settingsShortcutTokenEl;
      this.settingsStatusEl = settingsStatusEl;
      this.settingsCloseButtonEl = settingsCloseButtonEl;
      this.settingsSaveButtonEl = settingsSaveButtonEl;
      this.settingsFormEl = settingsFormEl;
      this.copyButtonEl.addEventListener("click", (event) => {
        event.preventDefault();
        event.stopPropagation();
        void this.copyCurrentSelection();
      });
      this.copyButtonEl.addEventListener("pointerdown", (event) => {
        event.preventDefault();
        event.stopPropagation();
      });
      this.toastSettingsButtonEl.addEventListener("pointerdown", (event) => {
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();
      });
      this.toastSettingsButtonEl.addEventListener("click", (event) => {
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();
        this.showSettingsPanel();
      });
      this.settingsCloseButtonEl.addEventListener("click", (event) => {
        event.preventDefault();
        event.stopPropagation();
        this.hideSettingsPanel();
      });
      this.settingsPanelEl.addEventListener("pointerdown", (event) => {
        if (event.target !== this.settingsInputEl && this.shortcutInputFocused) {
          this.settingsInputEl.blur();
        }
      });
      this.settingsInputEl.addEventListener("keydown", (event) => {
        this.handleSettingsShortcutInput(event);
      });
      this.settingsInputEl.addEventListener("focus", () => {
        this.beginShortcutCapture();
      });
      this.settingsInputEl.addEventListener("blur", () => {
        this.endShortcutCapture();
      });
      this.settingsFormEl.addEventListener("submit", (event) => {
        event.preventDefault();
        void this.saveToggleShortcut();
      });
      void this.loadToggleShortcut();
    }
    toggle() {
      if (this.state === "idle") {
        this.enterInspectMode();
        return;
      }
      this.exitInspectMode();
    }
    toggleByShortcut() {
      if (this.state === "idle") {
        this.enterInspectMode();
        return;
      }
      this.exitInspectMode();
    }
    ensureHostConnected() {
      if (!this.host.isConnected) {
        document.documentElement.appendChild(this.host);
      }
    }
    renderHostVisibility() {
      this.host.style.display = this.state === "idle" && !this.settingsVisible && !this.toastVisible ? "none" : "block";
    }
    showSettingsPanel() {
      this.ensureHostConnected();
      this.settingsVisible = true;
      this.settingsPanelEl.style.display = "flex";
      this.settingsPanelEl.setAttribute("aria-hidden", "false");
      this.settingsInputEl.value = this.toggleShortcut.label;
      this.renderShortcutToken();
      this.settingsStatusEl.textContent = "";
      this.renderHostVisibility();
    }
    hideSettingsPanel() {
      this.settingsInputEl.blur();
      this.endShortcutCapture({ immediate: true });
      this.settingsVisible = false;
      this.settingsPanelEl.style.display = "none";
      this.settingsPanelEl.setAttribute("aria-hidden", "true");
      this.settingsStatusEl.textContent = "";
      this.renderHostVisibility();
    }
    beginShortcutCapture() {
      this.shortcutInputFocused = true;
      this.clearShortcutTokenLeaveTimer();
      this.renderShortcutToken();
      this.settingsShortcutFieldEl.classList.remove("is-leaving");
      this.settingsShortcutFieldEl.classList.add("is-focused");
    }
    endShortcutCapture(options = {}) {
      this.shortcutInputFocused = false;
      this.clearShortcutTokenLeaveTimer();
      this.renderShortcutToken();
      this.settingsShortcutFieldEl.classList.remove("is-focused");
      this.settingsShortcutFieldEl.classList.add("is-leaving");
      if (options.immediate) {
        this.settingsShortcutFieldEl.classList.remove("is-leaving");
        return;
      }
      this.shortcutTokenLeaveTimer = window.setTimeout(() => {
        this.settingsShortcutFieldEl.classList.remove("is-leaving");
        this.renderShortcutToken();
        this.shortcutTokenLeaveTimer = null;
      }, SHORTCUT_TOKEN_LEAVE_MS);
    }
    clearShortcutTokenLeaveTimer() {
      if (this.shortcutTokenLeaveTimer !== null) {
        window.clearTimeout(this.shortcutTokenLeaveTimer);
        this.shortcutTokenLeaveTimer = null;
      }
    }
    renderShortcutToken() {
      this.settingsShortcutTokenEl.textContent = this.settingsInputEl.value.trim() || this.toggleShortcut.label;
    }
    handleSettingsShortcutInput(event) {
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation();
      if (event.key === "Tab") {
        return;
      }
      if (event.key === "Escape") {
        this.hideSettingsPanel();
        return;
      }
      if (event.key === "Backspace" || event.key === "Delete") {
        this.settingsInputEl.value = "";
        this.renderShortcutToken();
        this.settingsStatusEl.textContent = "\u8BF7\u91CD\u65B0\u6309\u4E00\u4E2A\u7EC4\u5408\u952E";
        return;
      }
      const shortcut = shortcutFromKeyboardEvent(event);
      if (!shortcut) {
        return;
      }
      this.settingsInputEl.value = shortcut.label;
      this.renderShortcutToken();
      this.settingsStatusEl.textContent = "";
    }
    async saveToggleShortcut() {
      const value = this.settingsInputEl.value.trim();
      const parsed = parseShortcut(value);
      if (!parsed) {
        this.settingsStatusEl.textContent = "\u5FEB\u6377\u952E\u683C\u5F0F\u4E0D\u5BF9";
        return;
      }
      await chrome.storage.local.set({ [TOGGLE_SHORTCUT_STORAGE_KEY]: parsed.label });
      this.toggleShortcut = parsed;
      this.settingsInputEl.value = parsed.label;
      this.renderShortcutToken();
      this.settingsInputEl.blur();
      this.endShortcutCapture({ immediate: true });
      this.settingsStatusEl.textContent = "\u5DF2\u4FDD\u5B58";
    }
    async loadToggleShortcut() {
      try {
        const stored = await chrome.storage.local.get(TOGGLE_SHORTCUT_STORAGE_KEY);
        this.applyToggleShortcut(stored[TOGGLE_SHORTCUT_STORAGE_KEY]);
      } catch {
        this.toggleShortcut = parseShortcut(DEFAULT_TOGGLE_SHORTCUT);
      }
    }
    applyToggleShortcut(value) {
      if (typeof value === "string") {
        const parsed = parseShortcut(value);
        if (parsed) {
          this.toggleShortcut = parsed;
          if (this.settingsVisible) {
            this.settingsInputEl.value = parsed.label;
            this.renderShortcutToken();
          }
          return;
        }
      }
      this.toggleShortcut = parseShortcut(DEFAULT_TOGGLE_SHORTCUT);
      if (this.settingsVisible) {
        this.settingsInputEl.value = this.toggleShortcut.label;
        this.renderShortcutToken();
      }
    }
    enterInspectMode() {
      this.ensureHostConnected();
      this.state = "inspecting";
      this.currentElement = null;
      this.hoverElement = null;
      this.currentDescriptor = null;
      this.setCopyButtonVisible(false);
      this.renderSelection(null);
      this.renderHoverSelection(null);
      document.addEventListener("mousemove", this.handleMouseMove, true);
      document.addEventListener("click", this.handleDocumentClick, true);
      document.addEventListener("keydown", this.handleKeydown, true);
      window.addEventListener("scroll", this.handleViewportChange, true);
      window.addEventListener("resize", this.handleViewportChange, true);
      this.renderHostVisibility();
      this.showStartupToast();
    }
    exitInspectMode() {
      this.state = "idle";
      this.settingsVisible = false;
      this.settingsInputEl.blur();
      this.endShortcutCapture({ immediate: true });
      this.settingsPanelEl.style.display = "none";
      this.settingsPanelEl.setAttribute("aria-hidden", "true");
      this.currentElement = null;
      this.hoverElement = null;
      this.currentDescriptor = null;
      this.pointerClientX = null;
      this.pointerClientY = null;
      this.drillStack.length = 0;
      this.selectionHistory.length = 0;
      this.historyIndex = -1;
      if (this.refreshFrame !== null) {
        window.cancelAnimationFrame(this.refreshFrame);
        this.refreshFrame = null;
      }
      this.setCopyButtonVisible(false);
      this.renderSelection(null);
      this.renderHoverSelection(null);
      this.hideToast({ updateHostVisibility: false });
      document.removeEventListener("mousemove", this.handleMouseMove, true);
      document.removeEventListener("click", this.handleDocumentClick, true);
      document.removeEventListener("keydown", this.handleKeydown, true);
      window.removeEventListener("scroll", this.handleViewportChange, true);
      window.removeEventListener("resize", this.handleViewportChange, true);
      this.showExitToast();
    }
    clearLockedSelection() {
      this.state = "inspecting";
      this.currentElement = null;
      this.hoverElement = null;
      this.currentDescriptor = null;
      this.setCopyButtonVisible(false);
      this.renderSelection(null);
      this.renderHoverSelection(null);
    }
    lockSelection(element, source, options) {
      if (!this.isSelectableElement(element)) {
        return false;
      }
      if (options?.resetDrillStack) {
        this.drillStack.length = 0;
      }
      this.currentElement = element;
      this.hoverElement = null;
      this.currentDescriptor = this.describeElement(element);
      this.state = "locked";
      if (options?.followViewport) {
        this.ensureSelectionInViewport(element);
      }
      const isVisible = this.renderSelection(element, this.currentDescriptor.friendlyName);
      this.setCopyButtonVisible(isVisible);
      this.renderHoverSelection(null);
      if (options?.recordHistory ?? true) {
        this.recordHistory(element);
      }
      if (source === "click" || source === "sibling" || source === "undo") {
        this.drillStack.length = 0;
      }
      return true;
    }
    recordHistory(element) {
      if (this.historyIndex >= 0 && this.selectionHistory[this.historyIndex] === element) {
        return;
      }
      this.selectionHistory.splice(this.historyIndex + 1);
      this.selectionHistory.push(element);
      this.historyIndex = this.selectionHistory.length - 1;
    }
    findSelectableAncestor(element) {
      let current = element;
      while (current) {
        if (this.isSelectableElement(current)) {
          return current;
        }
        current = current.parentElement;
      }
      return null;
    }
    findSelectableDescendant(element) {
      if (!element) {
        return null;
      }
      let currentLevel = Array.from(element.children);
      while (currentLevel.length > 0) {
        const nextLevel = [];
        for (const child of currentLevel) {
          if (this.isSelectableElement(child)) {
            return child;
          }
          nextLevel.push(...Array.from(child.children));
        }
        currentLevel = nextLevel;
      }
      return null;
    }
    findSelectableSibling(step) {
      if (!this.currentElement?.parentElement) {
        return null;
      }
      const siblings = Array.from(this.currentElement.parentElement.children).filter(
        (child) => this.isSelectableElement(child)
      );
      if (siblings.length <= 1) {
        return null;
      }
      const currentIndex = siblings.indexOf(this.currentElement);
      if (currentIndex < 0) {
        return null;
      }
      const nextIndex = (currentIndex + step + siblings.length) % siblings.length;
      return siblings[nextIndex] ?? null;
    }
    undoSelection() {
      if (this.state !== "locked") {
        return;
      }
      let nextIndex = this.historyIndex - 1;
      while (nextIndex >= 0) {
        const candidate = this.selectionHistory[nextIndex];
        if (candidate?.isConnected && this.isSelectableElement(candidate)) {
          this.historyIndex = nextIndex;
          this.lockSelection(candidate, "undo", { resetDrillStack: true, recordHistory: false, followViewport: true });
          return;
        }
        nextIndex -= 1;
      }
      this.showToast("\u5DF2\u662F\u6700\u65E9\u9009\u533A");
    }
    handleViewportChange = () => {
      if (this.state === "idle") {
        return;
      }
      if (this.refreshFrame !== null) {
        return;
      }
      this.refreshFrame = window.requestAnimationFrame(() => {
        this.refreshFrame = null;
        if (this.state === "locked") {
          this.refreshLockedSelection();
        }
        this.syncPointerTarget();
      });
    };
    refreshLockedSelection() {
      if (this.state !== "locked" || !this.currentElement) {
        return;
      }
      if (!this.currentElement.isConnected || !this.isSelectableElement(this.currentElement)) {
        this.clearLockedSelection();
        this.showToast("\u9009\u533A\u5DF2\u5931\u6548");
        return;
      }
      const label = this.currentDescriptor?.friendlyName ?? this.describeElement(this.currentElement).friendlyName;
      const isVisible = this.renderSelection(this.currentElement, label);
      this.setCopyButtonVisible(isVisible);
    }
    handleMouseMove = (event) => {
      if (this.state === "idle") {
        return;
      }
      if (this.isEventInsideUi(event)) {
        return;
      }
      this.pointerClientX = event.clientX;
      this.pointerClientY = event.clientY;
      this.syncPointerTarget();
    };
    handleDocumentClick = (event) => {
      if (this.state === "idle") {
        return;
      }
      if (this.isEventInsideUi(event)) {
        return;
      }
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation();
      const element = this.pickElement(event.clientX, event.clientY);
      if (!element) {
        return;
      }
      if (!this.isSupportedTarget(element)) {
        this.showToast(this.getUnsupportedReason(element));
        this.state = "inspecting";
        this.setCopyButtonVisible(false);
        return;
      }
      this.lockSelection(element, "click", { resetDrillStack: true, recordHistory: true });
      if (event.button === 0 && hasPrimaryModifier(event)) {
        void this.copyCurrentSelection();
      }
    };
    handleKeydown = (event) => {
      if (this.shortcutInputFocused || event.composedPath().includes(this.settingsInputEl)) {
        return;
      }
      const normalizedKey = event.key.toLowerCase();
      const isUndoShortcut = this.state === "locked" && !event.shiftKey && !event.altKey && normalizedKey === "z" && hasPrimaryModifier(event);
      if (isUndoShortcut) {
        event.preventDefault();
        event.stopPropagation();
        this.undoSelection();
        return;
      }
      const isCopyShortcut = this.state === "locked" && !event.shiftKey && !event.altKey && normalizedKey === "c" && hasPrimaryModifier(event);
      if (isCopyShortcut) {
        event.preventDefault();
        event.stopPropagation();
        void this.copyCurrentSelection();
        return;
      }
      if (this.state === "locked" && event.key === "Tab") {
        event.preventDefault();
        event.stopPropagation();
        const sibling = this.findSelectableSibling(event.shiftKey ? -1 : 1);
        if (!sibling) {
          this.showToast("\u6CA1\u6709\u5176\u4ED6\u540C\u7EA7\u5143\u7D20");
          return;
        }
        this.lockSelection(sibling, "sibling", { resetDrillStack: true, recordHistory: true, followViewport: true });
        return;
      }
      if (this.state === "locked" && event.key === "Enter" && event.shiftKey) {
        event.preventDefault();
        event.stopPropagation();
        const ancestor = this.findSelectableAncestor(this.currentElement?.parentElement ?? null);
        if (!ancestor) {
          this.showToast("\u5DF2\u5230\u6700\u5916\u5C42");
          return;
        }
        this.lockSelection(ancestor, "ancestor", { resetDrillStack: true, recordHistory: true, followViewport: true });
        return;
      }
      if (this.state === "locked" && event.key === "Enter" && !event.shiftKey) {
        event.preventDefault();
        event.stopPropagation();
        const child = this.findSelectableDescendant(this.currentElement);
        if (!child) {
          this.showToast("\u6CA1\u6709\u53EF\u9009\u5B50\u7EA7");
          return;
        }
        this.lockSelection(child, "descendant", { resetDrillStack: true, recordHistory: true, followViewport: true });
        return;
      }
      if (event.key !== "Escape") {
        return;
      }
      event.preventDefault();
      event.stopPropagation();
      if (this.state === "locked") {
        this.clearLockedSelection();
        this.showToast("\u5DF2\u53D6\u6D88\u9501\u5B9A\uFF0C\u518D\u6309 Esc \u9000\u51FA");
        return;
      }
      this.exitInspectMode();
    };
    handleGlobalKeydown = (event) => {
      if (this.shortcutInputFocused || event.composedPath().includes(this.settingsInputEl)) {
        return;
      }
      const isTyping = isTypingTarget(event.target);
      if (isTyping || !matchesShortcut(event, this.toggleShortcut)) {
        return;
      }
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation();
      this.toggleByShortcut();
    };
    handleStorageChange = (changes, areaName) => {
      if (areaName !== "local" || !(TOGGLE_SHORTCUT_STORAGE_KEY in changes)) {
        return;
      }
      this.applyToggleShortcut(changes[TOGGLE_SHORTCUT_STORAGE_KEY]?.newValue);
    };
    isEventInsideUi(event) {
      return event.composedPath().includes(this.host);
    }
    pickElement(clientX, clientY) {
      const candidate = document.elementFromPoint(clientX, clientY);
      if (!candidate) {
        return null;
      }
      return this.findSelectableElement(candidate);
    }
    findSelectableElement(start) {
      let current = start;
      while (current) {
        if (current === this.host || this.host.contains(current)) {
          return null;
        }
        const tagName = current.tagName.toLowerCase();
        if (tagName === "html" || tagName === "body") {
          return null;
        }
        if (this.isMeaningfulElement(current)) {
          return current;
        }
        current = current.parentElement;
      }
      return null;
    }
    isMeaningfulElement(element) {
      if (!(element instanceof HTMLElement)) {
        return false;
      }
      const rect = element.getBoundingClientRect();
      if (rect.width < 8 || rect.height < 8) {
        return false;
      }
      const style = window.getComputedStyle(element);
      if (style.display === "none" || style.visibility === "hidden" || Number.parseFloat(style.opacity || "1") === 0) {
        return false;
      }
      return true;
    }
    isSupportedTarget(element) {
      return element.tagName.toLowerCase() !== "canvas";
    }
    isSelectableElement(element) {
      if (element === this.host || this.host.contains(element)) {
        return false;
      }
      const tagName = element.tagName.toLowerCase();
      if (tagName === "html" || tagName === "body") {
        return false;
      }
      return this.isMeaningfulElement(element) && this.isSupportedTarget(element);
    }
    getUnsupportedReason(element) {
      if (element.tagName.toLowerCase() === "canvas") {
        return "\u6682\u4E0D\u652F\u6301 Canvas";
      }
      return "\u6682\u4E0D\u652F\u6301\u6B64\u533A\u57DF";
    }
    syncPointerTarget() {
      if (this.pointerClientX === null || this.pointerClientY === null) {
        if (this.state === "locked") {
          this.hoverElement = null;
          this.renderHoverSelection(null);
        }
        return;
      }
      const element = this.pickElement(this.pointerClientX, this.pointerClientY);
      if (!element) {
        if (this.state === "locked") {
          this.hoverElement = null;
          this.renderHoverSelection(null);
          return;
        }
        this.currentElement = null;
        this.currentDescriptor = null;
        this.setCopyButtonVisible(false);
        this.renderSelection(null);
        return;
      }
      if (this.state === "locked") {
        if (element === this.currentElement) {
          this.hoverElement = null;
          this.renderHoverSelection(null);
          return;
        }
        this.hoverElement = element;
        this.renderHoverSelection(element);
        return;
      }
      this.currentElement = element;
      this.currentDescriptor = this.describeElement(element);
      const isVisible = this.renderSelection(element, this.currentDescriptor.friendlyName);
      this.setCopyButtonVisible(isVisible);
    }
    getRenderableRect(element) {
      const rect = element.getBoundingClientRect();
      if (rect.width <= 0 || rect.height <= 0) {
        return null;
      }
      const isInViewport = rect.bottom > 0 && rect.right > 0 && rect.top < window.innerHeight && rect.left < window.innerWidth;
      return isInViewport ? rect : null;
    }
    ensureSelectionInViewport(element) {
      const rect = element.getBoundingClientRect();
      if (rect.width <= 0 || rect.height <= 0) {
        return;
      }
      const isAboveViewport = rect.top < 0;
      const isBelowViewport = rect.bottom > window.innerHeight;
      if (!isAboveViewport && !isBelowViewport) {
        return;
      }
      element.scrollIntoView({
        block: "center",
        inline: "nearest",
        behavior: "auto"
      });
    }
    renderHoverSelection(element) {
      if (!element) {
        this.hoverBorderEl.style.display = "none";
        return false;
      }
      const rect = this.getRenderableRect(element);
      if (!rect) {
        this.hoverBorderEl.style.display = "none";
        return false;
      }
      this.hoverBorderEl.style.display = "block";
      this.hoverBorderEl.style.left = `${rect.left}px`;
      this.hoverBorderEl.style.top = `${rect.top}px`;
      this.hoverBorderEl.style.width = `${rect.width}px`;
      this.hoverBorderEl.style.height = `${rect.height}px`;
      return true;
    }
    renderSelection(element, label = "") {
      if (!element) {
        this.borderEl.classList.remove("cf-chip-bottom");
        this.borderEl.style.display = "none";
        this.labelEl.style.display = "none";
        this.setCopyButtonVisible(false);
        return false;
      }
      const rect = this.getRenderableRect(element);
      if (!rect) {
        this.borderEl.classList.remove("cf-chip-bottom");
        this.borderEl.style.display = "none";
        this.labelEl.style.display = "none";
        this.setCopyButtonVisible(false);
        return false;
      }
      const chipHeight = 21;
      const shouldFlipChips = rect.top < chipHeight + 8;
      this.borderEl.classList.toggle("cf-chip-bottom", shouldFlipChips);
      this.borderEl.style.display = "block";
      this.borderEl.style.left = `${rect.left}px`;
      this.borderEl.style.top = `${rect.top}px`;
      this.borderEl.style.width = `${rect.width}px`;
      this.borderEl.style.height = `${rect.height}px`;
      this.labelEl.style.maxWidth = `${Math.max(48, Math.min(420, window.innerWidth - rect.left - 72))}px`;
      if (label) {
        this.labelEl.textContent = label;
        this.labelEl.style.display = "flex";
      } else {
        this.labelEl.style.display = "none";
      }
      return true;
    }
    setCopyButtonVisible(visible) {
      this.copyButtonEl.style.display = visible ? "inline-flex" : "none";
    }
    async copyCurrentSelection() {
      if (!this.currentDescriptor) {
        this.showToast("\u8BF7\u5148\u9009\u62E9\u533A\u57DF");
        return;
      }
      const output = this.currentDescriptor.output;
      const pageUrl = await getCurrentPageUrl();
      const text = `\u9875\u9762\uFF1A<${pageUrl}>
${output}
`;
      const copied = await copyText(text);
      if (!copied) {
        this.showToast("\u590D\u5236\u5931\u8D25\uFF0C\u8BF7\u91CD\u8BD5");
        return;
      }
      this.showToast("\u5DF2\u590D\u5236");
    }
    showStartupToast() {
      if (window.top !== window) {
        return;
      }
      this.showToast(STARTUP_TOAST_MESSAGE, { showSettingsButton: true });
    }
    showExitToast() {
      if (window.top !== window) {
        return;
      }
      this.showToast(EXIT_TOAST_MESSAGE);
    }
    showToast(message, options = {}) {
      this.ensureHostConnected();
      this.clearToastTimers();
      this.renderToastMessage(message);
      this.toastVisible = true;
      this.toastEl.classList.toggle("cf-toast--with-settings", Boolean(options.showSettingsButton));
      this.toastSettingsButtonEl.hidden = !options.showSettingsButton;
      this.toastSettingsButtonEl.classList.remove("is-visible");
      this.toastEl.setAttribute("aria-label", message);
      this.toastEl.classList.remove("is-entering", "is-visible", "is-leaving");
      this.toastEl.style.display = "block";
      this.renderHostVisibility();
      void this.toastEl.offsetWidth;
      this.toastEl.classList.add("is-entering");
      this.toastTimer = window.setTimeout(() => {
        this.toastEl.classList.remove("is-entering");
        this.toastEl.classList.add("is-visible");
        this.toastTimer = null;
      }, TOAST_ENTER_MS);
      if (options.showSettingsButton) {
        this.toastSettingsRevealTimer = window.setTimeout(() => {
          void this.toastSettingsButtonEl.offsetWidth;
          this.toastSettingsButtonEl.classList.add("is-visible");
          this.toastSettingsRevealTimer = null;
        }, getToastTextRevealDelay(message));
      }
      const leaveDelay = Math.max(TOAST_ENTER_MS, TOAST_TOTAL_MS - TOAST_LEAVE_MS);
      this.toastCleanupTimer = window.setTimeout(() => {
        this.toastEl.classList.remove("is-entering", "is-visible");
        this.toastEl.classList.add("is-leaving");
        this.toastCleanupTimer = window.setTimeout(() => {
          this.toastEl.classList.remove("is-leaving");
          this.toastEl.style.display = "none";
          this.toastEl.removeAttribute("aria-label");
          this.toastSettingsButtonEl.hidden = true;
          this.toastSettingsButtonEl.classList.remove("is-visible");
          this.toastEl.classList.remove("cf-toast--with-settings");
          this.toastVisible = false;
          this.renderHostVisibility();
          this.toastCleanupTimer = null;
        }, TOAST_LEAVE_MS);
      }, leaveDelay);
    }
    hideToast(options = {}) {
      this.clearToastTimers();
      this.toastEl.classList.remove("is-entering", "is-visible", "is-leaving", "cf-toast--with-settings");
      this.toastEl.style.display = "none";
      this.toastEl.removeAttribute("aria-label");
      this.toastSettingsButtonEl.hidden = true;
      this.toastSettingsButtonEl.classList.remove("is-visible");
      this.toastTextEl.replaceChildren();
      this.toastVisible = false;
      if (options.updateHostVisibility ?? true) {
        this.renderHostVisibility();
      }
    }
    clearToastTimers() {
      if (this.toastTimer) {
        window.clearTimeout(this.toastTimer);
        this.toastTimer = null;
      }
      if (this.toastCleanupTimer) {
        window.clearTimeout(this.toastCleanupTimer);
        this.toastCleanupTimer = null;
      }
      if (this.toastSettingsRevealTimer) {
        window.clearTimeout(this.toastSettingsRevealTimer);
        this.toastSettingsRevealTimer = null;
      }
    }
    renderToastMessage(message) {
      const fragment = document.createDocumentFragment();
      Array.from(message).forEach((char, index) => {
        const span = document.createElement("span");
        span.className = "cf-toast-char";
        span.textContent = char;
        span.style.setProperty(
          "--cf-char-delay",
          `${Math.min(index * TOAST_CHAR_STAGGER_MS, TOAST_CHAR_STAGGER_CAP_MS)}ms`
        );
        fragment.appendChild(span);
      });
      this.toastTextEl.replaceChildren(fragment);
    }
    describeElement(element) {
      const friendlyName = buildFriendlyName(element);
      const elementHints = collectElementHints(element).slice(0, MAX_HINTS);
      const ancestorHints = collectAncestorHints(element).slice(0, 3);
      const selector = buildReadableSelector(element);
      const textSnippet = getTextSnippet(element);
      const pageContext = buildPageContext();
      const contextHint = buildDisambiguationContext(element, ancestorHints);
      const target = shouldIncludeContext(element, friendlyName, selector, contextHint) ? `${contextHint} > ${friendlyName}` : friendlyName;
      const output = selector ? `[${pageContext}] ${target} :: ${selector}` : `[${pageContext}] ${target}`;
      return {
        friendlyName,
        elementHints,
        ancestorHints,
        selector,
        textSnippet,
        pageContext,
        output
      };
    }
  };
  function ensureInspector() {
    if (!window.__copyFrameInspector) {
      window.__copyFrameInspector = new CopyFrameInspector();
    }
    return window.__copyFrameInspector;
  }
  ensureInspector();
  function buildFriendlyName(element) {
    const preferredName = readAttribute(element, ["data-testid", "data-test-id", "data-qa", "data-cy"]) || element.getAttribute("name") || element.getAttribute("aria-label") || getAssociatedLabel(element) || element.getAttribute("id");
    if (preferredName) {
      return sanitizeText(preferredName);
    }
    const role = element.getAttribute("role");
    if (role) {
      return `${role}-${element.tagName.toLowerCase()}`;
    }
    const stableClass = getStableClassName(element);
    if (stableClass) {
      return stableClass;
    }
    const textSnippet = getTextSnippet(element);
    if (textSnippet) {
      return `${element.tagName.toLowerCase()}-${textSnippet.slice(0, 24)}`;
    }
    return `${element.tagName.toLowerCase()}-region`;
  }
  function collectElementHints(element) {
    const hints = [];
    const namedAttrs = ["data-testid", "data-test-id", "data-qa", "data-cy", "name", "aria-label", "id"];
    namedAttrs.forEach((attr) => {
      const value = element.getAttribute(attr);
      if (value) {
        hints.push({ label: attr, value });
      }
    });
    const role = element.getAttribute("role");
    if (role) {
      hints.push({ label: "role", value: role });
    }
    const stableClass = getStableClassName(element);
    if (stableClass) {
      hints.push({ label: "class", value: stableClass });
    }
    const textSnippet = getTextSnippet(element);
    if (textSnippet) {
      hints.push({ label: "text", value: textSnippet });
    }
    return uniq(
      hints.map((entry) => `${entry.label}=${entry.value}`).filter((value) => value.length <= 100)
    );
  }
  function collectAncestorHints(element) {
    const hints = [];
    let current = element.parentElement;
    while (current && hints.length < 4) {
      const tag = current.tagName.toLowerCase();
      if (tag === "body" || tag === "html") {
        break;
      }
      const stableClass = getStableClassName(current);
      if (stableClass) {
        hints.push(`.${stableClass}`);
        current = current.parentElement;
        continue;
      }
      if (current.id) {
        hints.push(`#${sanitizeText(current.id)}`);
        current = current.parentElement;
        continue;
      }
      const testAttribute = readNamedAttribute(current, ["data-testid", "data-test-id", "data-qa", "data-cy"]);
      if (testAttribute) {
        hints.push(`${testAttribute.name}=${sanitizeText(testAttribute.value)}`);
        current = current.parentElement;
        continue;
      }
      const ariaLabel = current.getAttribute("aria-label");
      if (ariaLabel) {
        hints.push(`aria-label="${sanitizeText(ariaLabel)}"`);
        current = current.parentElement;
        continue;
      }
      const heading = getContainedHeading(current);
      if (heading) {
        hints.push(`\u201C${heading}\u201D\u533A\u57DF`);
        current = current.parentElement;
        continue;
      }
      current = current.parentElement;
    }
    return uniq(hints);
  }
  function buildReadableSelector(element) {
    if (element.id) {
      return `${element.tagName.toLowerCase()}#${escapeSelector(element.id)}`;
    }
    const directSelector = buildDirectSelector(element);
    if (isUniqueSelector(directSelector, element)) {
      return directSelector;
    }
    const parts = [];
    let current = element;
    while (current && parts.length < 4) {
      const selector = buildDirectSelector(current);
      parts.unshift(selector);
      const combined = parts.join(" > ");
      if (isUniqueSelector(combined, element)) {
        return combined;
      }
      current = current.parentElement;
      if (!current || current.tagName.toLowerCase() === "body") {
        break;
      }
    }
    return parts.join(" > ") || element.tagName.toLowerCase();
  }
  function buildDirectSelector(element) {
    const tag = element.tagName.toLowerCase();
    const selectors = [tag];
    const testAttribute = readNamedAttribute(element, ["data-testid", "data-test-id", "data-qa", "data-cy"]);
    if (testAttribute) {
      selectors.push(`[${testAttribute.name}="${escapeSelector(testAttribute.value)}"]`);
      return selectors.join("");
    }
    if (element.getAttribute("name")) {
      selectors.push(`[name="${escapeSelector(element.getAttribute("name") || "")}"]`);
    } else if (element.getAttribute("aria-label")) {
      selectors.push(`[aria-label="${escapeSelector(element.getAttribute("aria-label") || "")}"]`);
    } else {
      const stableClass = getStableClassName(element);
      if (stableClass) {
        selectors.push(`.${escapeSelector(stableClass)}`);
      }
    }
    const nth = getNthOfType(element);
    if (nth > 1) {
      selectors.push(`:nth-of-type(${nth})`);
    }
    return selectors.join("");
  }
  function getSiblingIndexHint(element) {
    const parent = element.parentElement;
    if (!parent) {
      return "";
    }
    const sameTagSiblings = Array.from(parent.children).filter(
      (child) => child.tagName === element.tagName
    );
    if (sameTagSiblings.length <= 1) {
      return "";
    }
    const index = sameTagSiblings.indexOf(element) + 1;
    return `\u540C\u7EA7\u7B2C ${index} \u4E2A ${element.tagName.toLowerCase()} \u5143\u7D20`;
  }
  function buildDisambiguationContext(element, ancestorHints) {
    if (ancestorHints[0]) {
      return ancestorHints[0];
    }
    return getSiblingIndexHint(element);
  }
  function shouldIncludeContext(element, friendlyName, selector, contextHint) {
    if (!contextHint) {
      return false;
    }
    if (/:(nth-of-type|nth-child)\(/.test(selector)) {
      return true;
    }
    if (isGenericFriendlyName(friendlyName)) {
      return true;
    }
    const parent = element.parentElement;
    if (!parent) {
      return false;
    }
    const sameTagSiblings = Array.from(parent.children).filter(
      (child) => child.tagName === element.tagName
    );
    return sameTagSiblings.length > 1 && !hasStrongOwnIdentifier(element);
  }
  function isGenericFriendlyName(friendlyName) {
    const normalized = friendlyName.trim().toLowerCase();
    if (!normalized) {
      return true;
    }
    return normalized.endsWith("-region") || normalized === "button" || normalized === "link" || normalized === "input" || normalized === "section" || normalized === "container" || normalized === "dialog";
  }
  function hasStrongOwnIdentifier(element) {
    return Boolean(
      element.id || element.getAttribute("name") || element.getAttribute("aria-label") || readAttribute(element, ["data-testid", "data-test-id", "data-qa", "data-cy"])
    );
  }
  function getAssociatedLabel(element) {
    if (!(element instanceof HTMLElement)) {
      return null;
    }
    if (element.id) {
      const label = document.querySelector(`label[for="${escapeSelector(element.id)}"]`);
      if (label?.textContent) {
        return sanitizeText(label.textContent);
      }
    }
    const parentLabel = element.closest("label");
    if (parentLabel?.textContent) {
      return sanitizeText(parentLabel.textContent);
    }
    return null;
  }
  function getContainedHeading(element) {
    const heading = element.querySelector("h1, h2, h3, h4, h5, h6, [role='heading']");
    if (!heading?.textContent) {
      return null;
    }
    return sanitizeText(heading.textContent);
  }
  function getStableClassName(element) {
    for (const className of Array.from(element.classList)) {
      if (className.length >= 3 && !GENERIC_CLASS_NAMES.has(className.toLowerCase()) && /^[A-Za-z][A-Za-z0-9_-]+$/.test(className) && !/\d{4,}/.test(className)) {
        return className;
      }
    }
    return null;
  }
  function getTextSnippet(element) {
    const text = sanitizeText(element.textContent || "");
    if (!text) {
      return "";
    }
    return text.length > MAX_TEXT_LENGTH ? `${text.slice(0, MAX_TEXT_LENGTH - 1)}\u2026` : text;
  }
  function buildPageContext() {
    const title = sanitizeText(document.title || "");
    if (title) {
      return title;
    }
    const pathSegments = window.location.pathname.split("/").filter(Boolean);
    return pathSegments.at(-1) || window.location.host || "\u5F53\u524D\u9875\u9762";
  }
  function sanitizeText(value) {
    return value.replace(/\s+/g, " ").trim();
  }
  function readAttribute(element, attrs) {
    for (const attr of attrs) {
      const value = element.getAttribute(attr);
      if (value) {
        return value;
      }
    }
    return null;
  }
  function readNamedAttribute(element, attrs) {
    for (const attr of attrs) {
      const value = element.getAttribute(attr);
      if (value) {
        return { name: attr, value };
      }
    }
    return null;
  }
  function uniq(values) {
    return Array.from(new Set(values.filter(Boolean)));
  }
  function getToastTextRevealDelay(message) {
    const lastCharDelay = Math.min(
      Math.max(0, Array.from(message).length - 1) * TOAST_CHAR_STAGGER_MS,
      TOAST_CHAR_STAGGER_CAP_MS
    );
    return TOAST_TEXT_DELAY_MS + lastCharDelay + TOAST_CHAR_ENTER_MS + TOAST_SETTINGS_REVEAL_BUFFER_MS;
  }
  function getNthOfType(element) {
    const parent = element.parentElement;
    if (!parent) {
      return 1;
    }
    const siblings = Array.from(parent.children).filter((child) => child.tagName === element.tagName);
    return siblings.indexOf(element) + 1;
  }
  function isUniqueSelector(selector, element) {
    if (!selector) {
      return false;
    }
    try {
      return document.querySelectorAll(selector).length === 1 && document.querySelector(selector) === element;
    } catch {
      return false;
    }
  }
  function escapeSelector(value) {
    if (typeof CSS !== "undefined" && typeof CSS.escape === "function") {
      return CSS.escape(value);
    }
    return value.replace(/["\\]/g, "\\$&");
  }
  function hasPrimaryModifier(event) {
    return event.ctrlKey && !event.metaKey || event.metaKey && !event.ctrlKey;
  }
  function isTypingTarget(target) {
    if (!(target instanceof Element)) {
      return false;
    }
    const editable = target.closest("input, textarea, select, [contenteditable=''], [contenteditable='true']");
    return editable !== null;
  }
  async function copyText(value) {
    try {
      await navigator.clipboard.writeText(value);
      return true;
    } catch {
      const fallback = document.createElement("textarea");
      fallback.value = value;
      fallback.setAttribute("readonly", "true");
      fallback.style.position = "fixed";
      fallback.style.opacity = "0";
      fallback.style.pointerEvents = "none";
      document.body.appendChild(fallback);
      fallback.select();
      const copied = document.execCommand("copy");
      fallback.remove();
      return copied;
    }
  }
  async function getCurrentPageUrl() {
    try {
      return window.top?.location.href || window.location.href;
    } catch {
      try {
        const response = await chrome.runtime.sendMessage({ type: GET_PAGE_URL });
        if (typeof response?.url === "string" && response.url) {
          return response.url;
        }
      } catch {
      }
    }
    return document.referrer || window.location.href;
  }
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type !== TOGGLE_INSPECT_MODE) {
      return;
    }
    ensureInspector().toggle();
    sendResponse({ ok: true });
  });
})();
